# -*-coding:utf-8 -*-

# NPClab_Package package --> traitement_deeplabcut package


# info
__version__ = "0.0.1"
__author__ = "steve didienne"
__date__ = "10/06/2020"
